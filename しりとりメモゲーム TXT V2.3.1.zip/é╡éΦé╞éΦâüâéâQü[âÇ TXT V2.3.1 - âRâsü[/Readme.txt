【初めに】
このしりとりメモゲームをダウンロードいただきありがとうございます。
このゲームはしりとり問題.txtを開いて始まります。
【遊び方】
例
しりとり
から始まり
「」
ゴリラ
上に上と下の文章に当てはまるようにしてください(上だとリンゴ)
【作者YouTubeページ】
https://www.youtube.com/channel/UC5Sgeu01pdU6rnkTe1R9IkQ
【Twitter】
@akaiyahon1

English
at first】
Thank you for downloading this Shiritori Memo Game.
This game starts by opening Shiritori Problem.txt.
【how to play】
example
Shiritori
Starting from
""
gorilla
Make sure it applies to the text above and below (apple above)
[Author YouTube page]
https://www.youtube.com/channel/UC5Sgeu01pdU6rnkTe1R9IkQ
[Twitter]
@ akaiyahon1